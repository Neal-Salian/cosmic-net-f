"""End-to-end policy-gradient training of the edge policy over a frozen GNN.

Signature: train_policy(trainer, graphs, gnns, cfg, device, epochs, log_fn)

graphs: list of dicts with x, edge_index, edge_attr, y, ctx (+ physics attrs).
"""
import torch
import torch.nn.functional as F
from torch_geometric.data import Batch
from torch_geometric.nn import global_mean_pool
from rls.policy_gradient import (compute_advantages, compute_pg_loss,
                                 bernoulli_logp, bernoulli_entropy, sample_actions)
from rls.sparsify import (apply_min_keep_floor, repair_connectivity,
                           symmetrize_probs, repair_symmetric,
                           topk_scheduled_mask)


def training_budget_report(edge_index, mask, cfg, *, order=None, num_nodes=None,
                           explicit_keep=None):
    """Accounting-only helper: requested/sampled/final counts for diagnostics.

    Training algorithm unchanged; callers pass the actual sampled order when
    known so declared requested/sample counts are not null.
    """
    from rls.budget_accounting import legacy_repair_report, resolve_requested_keep
    q = resolve_requested_keep(cfg, explicit=explicit_keep)
    return legacy_repair_report(edge_index, mask, keep_fraction=q, order=order,
                                num_nodes=num_nodes)


def check_curriculum_divergence(keep_hist, target_hist, tol=0.1,
                                patience=5, anneal_epochs=40):
    """Pure helper (audit P0-reward, Sep 2026): True iff |keep - target| > tol
    for `patience` consecutive epochs strictly after anneal_epochs / 2.

    This check would have caught the diagnosed failure automatically (keep
    stalled at 0.96-1.0 while the target annealed to 0.40). Unit-tested in
    tests/test_train_policy.py; the training loop calls it every epoch.
    """
    start = anneal_epochs / 2
    run = 0
    for epoch, (keep, target) in enumerate(zip(keep_hist, target_hist)):
        if epoch <= start:
            continue
        if abs(keep - target) > tol:
            run += 1
            if run >= patience:
                return True
        else:
            run = 0
    return False
from rls.rewards import compute_rewards, relative_virial_penalty


def _graph_physics_terms(graph, edge_index, mask, G=4.302e-9):
    """ke_retained, pe_retained per graph (see rewards.py docstring).

    PHYSICS EDGES EXCLUDE SELF-LOOPS (u == v): a self-pair is not a pairwise
    interaction, and its r == 0 would clamp to 1e-6 and dominate PE by orders
    of magnitude (the dead-virial-term bug found by the Aug 2026 audit —
    measured: self-loops carried ~100% of PE and the resulting ratio ~4e-5 made
    the old one-sided penalty identically zero). GNN message-passing keeps its
    self-loops; this filter is physics-only."""
    assert mask.dtype == torch.bool, f"expected bool mask, got {mask.dtype}"
    real = edge_index[0] != edge_index[1]
    edge_index = edge_index[:, real]
    mask = mask[real]
    stellar = graph["stellar_mass"]  # [N]
    vel_disp = graph["vel_disp"]     # [N]
    pos = graph["pos"]               # [N,3]
    deg = torch.zeros(stellar.numel(), device=stellar.device)
    deg.index_add_(0, edge_index[0], torch.ones(edge_index.shape[1], device=stellar.device))
    deg.index_add_(0, edge_index[1], torch.ones(edge_index.shape[1], device=stellar.device))
    deg_ret = torch.zeros_like(deg)
    deg_ret.index_add_(0, edge_index[0, mask], torch.ones(mask.sum(), device=stellar.device))
    deg_ret.index_add_(0, edge_index[1, mask], torch.ones(mask.sum(), device=stellar.device))
    frac = deg_ret / deg.clamp(min=1)
    ke = 0.5 * torch.sum(frac * stellar * vel_disp ** 2)
    u, v = edge_index[0, mask], edge_index[1, mask]
    r = torch.norm(pos[u] - pos[v], dim=1)
    pe = torch.sum(G * stellar[u] * stellar[v] / r.clamp(min=1e-6))
    return ke, pe


def _no_isolated(edge_index, mask):
    """True iff every node keeps >= 1 incident edge under `mask`.
    Device-safe: the degree accumulator lives on edge_index's device."""
    device = edge_index.device
    deg = torch.zeros(int(edge_index.max().item()) + 1, dtype=torch.long, device=device)
    kept = (mask & (edge_index[0] != edge_index[1])).nonzero(as_tuple=False).squeeze(-1)
    if kept.numel() > 0:
        ones = torch.ones(kept.numel(), dtype=torch.long, device=device)
        deg.index_add_(0, edge_index[0, kept], ones)
        deg.index_add_(0, edge_index[1, kept], ones)
    return bool((deg >= 1).all())


def prepare_graphs(loader, gnn, device=None):
    """Adapter: PyG loader -> list of per-graph dicts for policy training.

    Uses batch.get_example(i) (the same pattern as explain/explainer.py's
    explain_batch) so per-graph tensors keep their original indices — NO
    fragile boolean-mask remapping. Precomputes frozen node embeddings and
    the graph context once (GNN stays frozen and in eval mode).

    device defaults to the GNN's own device — never trust a caller-passed
    device that mismatches the GNN (that mixes cpu graphs with cuda emb)."""
    if device is None:
        device = next(gnn.parameters()).device
    graphs = []
    gnn.eval()
    with torch.no_grad():
        for batch in loader:
            batch = batch.to(device)
            for i in range(batch.num_graphs):
                g = batch.get_example(i).to(device)
                b = Batch.from_data_list([g])
                emb = gnn.get_embeddings(b, embedding_point="pre_pooling")  # [N, out]
                ctx = global_mean_pool(emb, b.batch)                        # [1, out]
                graphs.append({
                    "x": g.x,
                    "edge_index": g.edge_index,
                    "edge_attr": g.edge_attr,
                    "y": g.y.view(1),
                    "ctx": ctx[0],
                    "emb": emb,                     # per-node [N, out] — the
                                                    # policy's node_emb input
                    "stellar_mass": getattr(g, "stellar_mass", None),
                    "vel_disp": getattr(g, "vel_disp", None),
                    "half_mass_r": getattr(g, "half_mass_r", None),
                    "pos": getattr(g, "pos", None),
                })
    return graphs


def train_policy(trainer, graphs, gnns, cfg, device="cpu", epochs=60, log_fn=None,
                 warn_fn=None, validation_fn=None):
    """One epoch = one pass over the graphs; batch = cfg['batch_size'] graphs.

    gnns: callable (graph_dict, mask) -> (pred_full, pred_pruned) or None
    (smoke mode: random placeholder predictions).
    Returns the per-epoch mean loss list.

    cfg['sparsity_mode'] (FIX Sep 2026, audit P0-reward): "penalty" (default,
    legacy soft w_sp penalty — preserved for comparison) or "topk_scheduled"
    (structural constraint: executed mask keeps top-k probs at the current
    curriculum target; probs learn WHICH edges to drop). warn_fn(epoch, keep,
    target) is called on curriculum divergence (default: print).
    """
    if cfg.get("sparsity_mode") == "pair_pl":
        from rls.pair_training import train_pair_policy
        return train_pair_policy(trainer, graphs, gnns, cfg, device, epochs,
                                 log_fn, validation_fn)
    if cfg.get("sparsity_mode") == "topk_scheduled":
        raise ValueError("topk_scheduled used a biased action likelihood. Retrain with sparsity_mode='pair_pl'.")
    policy, value_net = trainer.policy, trainer.value_net
    policy = policy.to(device)
    value_net = value_net.to(device)
    n = max(1, len(graphs))
    batch_size = cfg["batch_size"]
    losses = []

    def _update_batch(batch_graphs, target_sp):
        """One policy-gradient step on a mini-batch of graphs.

        Everything the policy must NOT differentiate through (mask repair, GNN
        forward, rewards, baseline) runs under no_grad. Only the sampled log
        probs and the entropy term carry policy gradients."""
        total_logp = []
        total_ent = []
        total_values = []
        total_rewards = []
        total_keep = []
        mode = cfg.get("sparsity_mode", "penalty")

        for g in batch_graphs:
            g = {k: v.to(device) for k, v in g.items() if isinstance(v, torch.Tensor)}
            probs = torch.sigmoid(policy(g["edge_attr"], g["emb"],
                                         g["edge_index"], g["ctx"])).squeeze(-1)
            # FIX (audit P0-2, Sep 2026): symmetrize probs BEFORE sampling so
            # both directions of a physical edge share one keep-probability.
            # The Bernoulli sample itself is still per-directed-edge (logp
            # stays on the raw sample per the convention below); the executed
            # mask is re-symmetrized by repair_symmetric so the frozen GNN
            # never sees a directionally-asymmetric topology.
            probs = symmetrize_probs(g["edge_index"], probs)
            action = sample_actions(probs)
            # logp is computed on the RAW sampled action, not the floored/repaired
            # mask — same convention as action-clipping in continuous control:
            # log-prob on the sample, the environment executes the repaired version.
            logp = bernoulli_logp(probs, action)
            ent = bernoulli_entropy(probs).mean()
            # value-net forward must stay OUTSIDE no_grad so vf_loss.backward()
            # has a graph to flow through (the baseline is learnable).
            val = value_net(g["ctx"])
            with torch.no_grad():
                if mode == "topk_scheduled":
                    # Structural constraint: executed mask keeps top-k probs
                    # at the curriculum target (see topk_scheduled_mask).
                    mask = repair_symmetric(
                        g["edge_index"],
                        topk_scheduled_mask(g["edge_index"], probs, target_sp))
                else:
                    mask = apply_min_keep_floor(action.bool(), probs,
                                                min_keep_frac=cfg.get("min_keep_frac", 0.1))
                    mask = repair_symmetric(g["edge_index"], mask)
                pred_full, pred_pruned = gnns(g, mask) if gnns else (torch.randn(1), torch.randn(1))
                # Relative virial (approved Aug 2026): loop-free full-graph
                # reference (action-independent, constant per graph) vs the
                # action-selected edges. _graph_physics_terms filters
                # self-loops internally, so passing the full edge_index with an
                # all-true mask yields the loop-free full-graph reference.
                ke_full, pe_full = _graph_physics_terms(
                    g, g["edge_index"], torch.ones_like(mask))
                ke, pe = _graph_physics_terms(g, g["edge_index"], mask)
                vp = (relative_virial_penalty(ke, pe, ke_full, pe_full)
                      if cfg.get("w_virial", 0) > 0 else torch.zeros(1).to(device))
                conn_ok = bool((mask.sum() > 0) and _no_isolated(g["edge_index"], mask))
                keep_ratio = mask.float().mean().item()
                rew = compute_rewards(pred_pruned, pred_full, g["y"], keep_ratio,
                                      target_sp, vp, cfg, connectivity_ok=conn_ok)
            if mode == "topk_scheduled":
                # Re-point logp at the EXECUTED mask OUTSIDE no_grad (inside,
                # the tensor would carry no grad and the policy would learn
                # nothing). Hard-attention-style REINFORCE: mask is a constant
                # action, gradient flows through logp's probs terms. Biased
                # (no sampling stochasticity in the executed mask; the entropy
                # bonus is the remaining explorer) but makes keep track the
                # curriculum by construction.
                logp = bernoulli_logp(probs, mask.float())
            total_logp.append(logp.mean())
            total_ent.append(ent)
            # Each episode has one value and reward. A [1] reward stacked
            # against scalar values otherwise broadcasts to a [B, B] loss.
            total_values.append(val.reshape(()))
            total_rewards.append(rew.reshape(()))
            total_keep.append(keep_ratio)

        logp = torch.stack(total_logp)
        entropy = torch.stack(total_ent).mean()
        values = torch.stack(total_values)
        rewards = torch.stack(total_rewards)

        adv = compute_advantages(rewards, values)
        loss, pg_loss, vf_loss, ent = compute_pg_loss(
            logp, adv, values, rewards,
            entropy=entropy,
            value_coef=cfg.get("value_coef", 0.5),
            entropy_coef=cfg.get("entropy_coef", 0.01))

        # Policy and value-net graphs are disjoint (advantages are detached);
        # ONE backward fills grads for both, then each optimizer steps its own
        # params. Two separate backward calls would re-traverse the value graph.
        trainer.optimizer.zero_grad()
        if trainer.value_optimizer is not None:
            trainer.value_optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(policy.parameters(), 1.0)
        trainer.optimizer.step()
        if trainer.value_optimizer is not None:
            trainer.value_optimizer.step()

        mean_keep = float(torch.tensor(total_keep).mean().item())
        return float(loss.item()), mean_keep

    keep_hist, target_hist = [], []
    for epoch in range(epochs):
        target_sp = trainer.target_sparsity(epoch)
        epoch_losses = []
        epoch_keeps = []
        for i in range(0, n, batch_size):
            l, k = _update_batch(graphs[i:i + batch_size], target_sp)
            epoch_losses.append(l)
            epoch_keeps.append(k)
        mean = torch.tensor(epoch_losses).mean()
        losses.append(mean)
        keep_hist.append(float(torch.tensor(epoch_keeps).mean().item()))
        target_hist.append(target_sp)
        # FIX (audit P0-reward, Sep 2026): curriculum-divergence guard. The
        # diagnosed run stalled at keep 0.96-1.0 vs target 0.40 with no alarm;
        # now |keep - target| > 0.1 persisting past half the anneal schedule
        # emits an explicit warning instead of failing silently.
        if check_curriculum_divergence(
                keep_hist, target_hist, tol=0.1, patience=5,
                anneal_epochs=cfg.get("sparsity_anneal_epochs", 40)):
            msg = (f"[rls] CURRICULUM DIVERGENCE at epoch {epoch}: "
                   f"mean keep {keep_hist[-1]:.3f} vs target {target_sp:.3f} "
                   f"(|keep-target| > 0.1 for 5+ epochs past half anneal). "
                   f"See sparsity_mode={cfg.get('sparsity_mode', 'penalty')}.")
            if warn_fn is not None:
                warn_fn(epoch, keep_hist[-1], target_sp)
            else:
                print(msg)
        if log_fn:
            log_fn(epoch, target_sp, float(mean))
    return losses
